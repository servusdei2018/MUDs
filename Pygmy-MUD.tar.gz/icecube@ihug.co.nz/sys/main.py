# Main module

St = sys.static()

class main(Object):
    singleton = 1

    def init(S):
        sys.conn.init()
        sys.user_conn.init()
        sys.ftp_conn.init()
        
    def tick(S):
        pass
        #driver.log("main.tick called")
    
