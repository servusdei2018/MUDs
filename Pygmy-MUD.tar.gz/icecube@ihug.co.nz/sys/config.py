# Configuration info

class config(Object):
    singleton = 1

    def __init__(S):
        S.mkadmin = 1    # make next player to create an admin
