#ifndef _PATCHES_H_
#define _PATCHES_H_

#define AUTOEQ_PATCH

#endif