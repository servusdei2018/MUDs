cl=[]
tick=0